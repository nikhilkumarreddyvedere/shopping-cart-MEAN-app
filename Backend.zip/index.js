var express = require('express');

var mongoose = require('mongoose');

var bodyparser = require('body-parser');

var cors = require('cors');

const route = require('./routes/router')

var app = express();

//connect to mongodb
mongoose.connect('mongodb://localhost:27017/shoppinglist',{useNewUrlParser: true});

//on connection
mongoose.connection.on('connected', function(){
    console.log('mongoose connected on port 27017');
});

//on connection error

mongoose.connection.on('error', function(error){
    console.log(error)
})

//adding middleware -- core

app.use(cors());


//adding body-parser 

app.use(bodyparser.json());

app.use('/api', route)

app.get('/',function(req,res){
res.send("hurry you are on home page");
});

app.listen(3000,function(){
console.log("app running on port 3000")    
})

