const express = require('express')

var router = express.Router();

const Item = require('../model/shoppinglist')

router.get('/items', function(req,res,next){
    Item.find(function(err,items){

        if(err){
            res.json(err);
        }

        res.json(items)
    })
})

router.post('/item',function(req,res,next){
   let newshoppingItem = new Item({
       itemName: req.body.itemName,
       itemQuantity: req.body.itemQuantity,
       itembrought : req.body.itemBrought
   });
newshoppingItem.save(function(err){
    if(err){
        res.json(err)
    }

    res.json({msg:"Item has been updated successfully"})
})

})

router.put('/item/:id',function(req,res,next){

    Item.findOneAndUpdate({_id: req.params.id},{

        $set:{
            itemName: req.body.itemName,
            itemQuantity: req.body.itemQuantity,
            itembrought: req.body.itemBrought
        }
    },
    function(err,result){

        if(err){
            res.json(err)
        }
        res.json(result)
    }
    
    )
})

router.delete('/item/:id',function(req,res,next){
Item.remove({_id: req.params.id}, function(err,result){
if(err){
    res.json(err)
}
else{
    res.json(result)
}
})
})

module.exports = router;