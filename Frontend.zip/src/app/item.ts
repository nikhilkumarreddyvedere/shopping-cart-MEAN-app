export class Item {
    _id? : string;
    itemName: string;
    itemQuantity: number;
    itemBrought: boolean;
}