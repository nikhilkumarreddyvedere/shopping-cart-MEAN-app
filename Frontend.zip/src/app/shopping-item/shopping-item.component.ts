import { Component, OnInit } from '@angular/core';
import {Item } from '../item';
import { DataService } from '../data.service'
import { NgForm } from '@angular/forms'
 
@Component({
  selector: 'app-shopping-item',
  templateUrl: './shopping-item.component.html',
  styleUrls: ['./shopping-item.component.css'],
  providers:[DataService]

})
export class ShoppingItemComponent implements OnInit {

  shoppingItemList: Item[]=[]; 

  selectItem: Item;

  toggleForm: boolean = false;

  constructor(private dataService: DataService) { }

  getItems(){
   this.dataService.getShoppingItem()
   .subscribe(
    item => this.shoppingItemList = item
      )
  }

  addItem(frm: NgForm){

    let  newItem : Item = {
      itemName: frm.value.Name,
      itemQuantity: frm.value.Quantity,
      itemBrought: false
    }
     this.dataService.addShoppingItem(newItem)
     .subscribe(item => {
       console.log(item);
       this.getItems();
     })
    //console.log(frm.value);
  }

  editItem(editfrm: NgForm){

    let  newItem : Item = {
      _id: this.selectItem._id,
      itemName: editfrm.value.Name,
      itemQuantity: editfrm.value.Quantity,
      itemBrought: this.selectItem.itemBrought
    }
     this.dataService.updateShoppingItem(newItem)
     .subscribe(item => {
       console.log(item);
       this.getItems();
     })
    //console.log(frm.value);
  }

  deleteItem(id){
   
    this.dataService.DeleteShoppingItem(id)
    .subscribe(data => console.log(data))
  }
  showEditForm(editfrm){
    this.selectItem = editfrm;
    this.toggleForm = !this.toggleForm;
  }
  ngOnInit() {
    this.getItems();
  }

}
